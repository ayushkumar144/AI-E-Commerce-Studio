#!/bin/bash
# usage: ./push.sh https://github.com/<username>/ai-ecommerce-studio.git
git init && git add . && git commit -m "Initial commit: AI E-Commerce Studio"
git branch -M main && git remote add origin "$1" && git push -u origin main
