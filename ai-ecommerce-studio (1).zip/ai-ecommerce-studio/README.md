# AI E-Commerce Studio

Turn structured product info into a marketplace-ready content package: SEO title, description, highlights, benefits, FAQs, promo copy, social post and an AI-generated promotional creative.

**Live demo (claude.ai):** https://claude.ai/artifact/GxY2cnBGXLW2GQ1xaT6c9M

## Features
- Auto-fill product details from just a product name (draft, edit before use)
- Platform-adapted output: Amazon, Shopify, Etsy, Flipkart, Instagram, Google Shopping
- Multilingual: English, Hindi, Spanish, French, German
- 4 creative styles; AI-generated SVG product creative
- Content-quality checker flags numbers and terms (certified, lifetime, etc.) not present in your input
- Export package as JSON and creative as SVG

## How it works
1. **Input** – name, category, price, features, specs, target customer, extras.
2. **Grounded copy** – the facts go to the LLM with strict rules: never invent specs, warranty, certifications or performance claims; answer "not specified" when unknown.
3. **Creative** – a second LLM call designs a 1080x1080 SVG from the headline, tagline, price and provided features only.
4. **Quality check** – client-side scan for unsupported claims.
5. **Export** – JSON + SVG.

## Notes
- Single file, no build step: `index.html`.
- AI calls use `claude.use("sample")` and `claude.use("downloads")`, which only work inside claude.ai. To run elsewhere, replace them with calls to your own backend or an LLM API (and an image API for photorealistic creatives).
